<?php
// السماح بالطلبات من موقعك فقط (Netlify) لزيادة الأمان
header("Access-Control-Allow-Origin: https://my-faucet-api.netlify.app");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json");

/**
 * Bee Faucet PHP Proxy - V9.7
 * تم دمج الـ API الخاص بك بنجاح
 */

$API_KEY = "Ec2bd1bf19008d250c68590433c9ec6ee2be17c71bc1de1725b87ca143d3b0b0";
$CURRENCY = "BNB";

// التحقق من أن الطلب قادم عبر POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // استقبال البيانات من التطبيق
    $address = isset($_POST['address']) ? $_POST['address'] : '';
    $amount  = isset($_POST['amount']) ? $_POST['amount'] : 0;

    // التأكد من وجود البيانات المطلوبة
    if (empty($address) || $amount <= 0) {
        echo json_encode(["status" => 400, "message" => "Missing data"]);
        exit;
    }

    // تجهيز الطلب لإرساله إلى FaucetPay
    $url = "https://faucetpay.io/api/v1/send";
    
    $data = [
        'api_key' => $API_KEY,
        'amount'  => $amount,
        'to'      => $address,
        'currency' => $CURRENCY,
        'referral' => 'false'
    ];

    // استخدام cURL لتنفيذ العملية
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // لتجنب مشاكل شهادات SSL على الاستضافات المجانية
    
    $response = curl_exec($ch);
    $curl_error = curl_error($ch);
    curl_close($ch);

    // إذا كان هناك خطأ في الاتصال بالسيرفر
    if ($curl_error) {
        echo json_encode(["status" => 500, "message" => "CURL Error: " . $curl_error]);
    } else {
        // إرجاع النتيجة كما جاءت من FaucetPay للتطبيق
        echo $response;
    }
} else {
    // منع الوصول المباشر للملف عبر المتصفح
    echo json_encode(["status" => 405, "message" => "Method Not Allowed"]);
}
?>
